<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RecAudioVisuais extends Model
{
    protected $table = 'recaudiovisuais';
    public $timestamps = false;
    protected $guarded = [];
}
