<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ServicosExtras extends Model
{
    protected $table = 'servicosextras';
    public $timestamps = false;
    protected $guarded = [];
}
